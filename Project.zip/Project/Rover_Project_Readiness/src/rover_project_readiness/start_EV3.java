package rover_project_readiness;

import java.util.*;
import lejos.hardware.ev3.LocalEV3;
import lejos.hardware.port.Port;        
import lejos.hardware.sensor.EV3UltrasonicSensor;
import java.util.concurrent.TimeUnit;

import lejos.hardware.motor.*;
import lejos.hardware.lcd.LCD;
import lejos.hardware.port.MotorPort;
import lejos.robotics.*;

public class start_EV3 {

	public static void main(String[] args) throws InterruptedException {
		
		Communications.startServer(9090);
		
		Port port3 = LocalEV3.get().getPort("S3") ;        
        EV3UltrasonicSensor sensor = new EV3UltrasonicSensor(port3) ;        
        SampleProvider distance= sensor.getMode("Distance") ;        
        float[] sample = new float[distance.sampleSize()] ;
		
		String command;
		
		RegulatedMotor mot_left = new EV3LargeRegulatedMotor(MotorPort.B);
		RegulatedMotor mot_right = new EV3LargeRegulatedMotor(MotorPort.C);
		
		mot_left.setAcceleration(1000);
		mot_right.setAcceleration(1000);
		
		mot_left.setSpeed(360);
		mot_right.setSpeed(360);
		
		while(true) {

			distance.fetchSample(sample, 0);
            Communications.send(Float.toString(sample[0]));
            
			command = null;
			
			TimeUnit.SECONDS.sleep(1);
			LCD.clear();
			
			while(command == null) {		
				command = Communications.recieve();
				//System.out.println(command);
			}
			
			ArrayList<String> data = new ArrayList<String>(Arrays.asList(command.split(",")));
			
			for(int i=0; i < data.size(); i++) {
				LCD.drawString(data.get(i), 0, i);
				
				//System.out.println(data.get(i));
			}
			
			if(command.compareTo("move,up") == 0) {
				//mot_left.rotate(250,true);
				//mot_right.rotate(250,true);		
				mot_right.forward();
				mot_left.forward();
			}
			else if(command.compareTo("move,left") == 0) {
				//mot_left.rotate(-50,true);
				//mot_right.rotate(50,true);
				mot_right.forward();
				mot_left.backward();
				
			}
			else if(command.compareTo("move,right") == 0) {
				//mot_left.rotate(50,true);
				//mot_right.rotate(-50,true);
				mot_right.backward();
				mot_left.forward();
				
			}
			else if(command.compareTo("move,stop") == 0) {
				mot_left.stop(true);
				mot_right.stop(true);
			}
			else if(command.compareTo("move,down") == 0) {
				mot_left.backward();
				mot_right.backward();
			}
		}
	}

}

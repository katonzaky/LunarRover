package rover_project_readiness;

import java.net.*;
import java.io.*; 

public class Communications {
	
	public static boolean err_source = false;
	
	public enum Mode {UNSET, SERVER, CLIENT};
	
	private static ServerSocket server;
	private static Socket socket;
	private static BufferedReader conn_in;
	private static PrintWriter conn_out;
	private static Mode mode = Mode.UNSET;
	
	public static void startServer(int port){
		
		try {
			if(mode == Mode.CLIENT) {
				System.err.println("Unable to configure as server. Already configured as a client. ");
				return;
			}
			
			mode = Mode.SERVER;
			
			server = new ServerSocket(port);
			
			socket = server.accept(); 
			
			conn_in = new BufferedReader(new InputStreamReader(socket.getInputStream()));
			conn_out = new PrintWriter(socket.getOutputStream(), true);
		}
		catch(IOException e) {			
			printErr(e);
		}
	}
	
	public static void connectToServer(String IP, int port) {
		
		if(mode == Mode.SERVER) {			
			System.err.println("Unable to configure as client. Already configured as a server. ");
			return;
		}
		
		mode = Mode.CLIENT;
		
		try {
			socket = new Socket(IP, port);
			
			conn_in = new BufferedReader(new InputStreamReader(socket.getInputStream()));
			conn_out = new PrintWriter(socket.getOutputStream(), true);
		}
		catch (IOException e) {
			printErr(e);
			mode = Mode.UNSET;
		}
	}
	
	public static void send(String data) {
		try{
			conn_out.println(data);
		}
		catch (NullPointerException e) {
			printErr(e);
		}
	}
	
	public static String recieve() {
		String data = new String();
		
		try {
			if(conn_in.ready()) {
				data = conn_in.readLine();		
			}
		}
		catch(IOException e) {			
			printErr(e);
		}
		catch (NullPointerException e) {
			printErr(e);
		}
			
		return data;
	}
	
	public static void close() {
		try {
			if(mode != Mode.UNSET) {
				socket.close();
			}			
			if(mode == Mode.SERVER) {
				server.close();
			}
						
			mode = Mode.UNSET;
		}
		catch(IOException e) {
			printErr(e);
		}
		catch (NullPointerException e) {
			printErr(e);
		}
	}
	
	private static void printErr(Exception e) {
		System.err.println("Caught " + e.toString());
		if(err_source == true) {
			e.printStackTrace(new PrintStream(System.err));
		}
	}
}

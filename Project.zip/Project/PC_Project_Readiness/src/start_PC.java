
import java.util.concurrent.TimeUnit;

import communications.Communications;

public class start_PC {

	public static void main(String[] args) throws InterruptedException {
		
		Communications.connectToServer("10.0.1.1", 9090);
		
		while(true) {
			Communications.send("move,up");
			TimeUnit.SECONDS.sleep(2);
			Communications.send("move,stop");
			TimeUnit.SECONDS.sleep(2);
			Communications.send("move,left");
			TimeUnit.SECONDS.sleep(2);
			Communications.send("move,stop");
			TimeUnit.SECONDS.sleep(2);
		}
	}

}
